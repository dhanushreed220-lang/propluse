import { useState, useEffect, useRef } from "react";

// ─── Fonts ───────────────────────────────────────────────────────────────────
const fontLink = document.createElement("link");
fontLink.rel = "stylesheet";
fontLink.href = "https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;1,9..40,300&display=swap";
document.head.appendChild(fontLink);

// ─── Global Styles ───────────────────────────────────────────────────────────
const style = document.createElement("style");
style.textContent = `
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --bg: #080c14;
    --bg2: #0d1320;
    --bg3: #111827;
    --surface: rgba(255,255,255,0.03);
    --surface2: rgba(255,255,255,0.06);
    --border: rgba(255,255,255,0.07);
    --border2: rgba(255,255,255,0.12);
    --accent: #3b82f6;
    --accent2: #6366f1;
    --accent3: #8b5cf6;
    --green: #10b981;
    --red: #ef4444;
    --yellow: #f59e0b;
    --orange: #f97316;
    --cyan: #06b6d4;
    --text: #f1f5f9;
    --text2: #94a3b8;
    --text3: #64748b;
    --font: 'Syne', sans-serif;
    --body: 'DM Sans', sans-serif;
    --radius: 12px;
    --radius2: 16px;
    --shadow: 0 4px 24px rgba(0,0,0,0.4);
    --glow: 0 0 40px rgba(59,130,246,0.15);
  }
  html, body { background: var(--bg); color: var(--text); font-family: var(--body); min-height: 100vh; }
  ::-webkit-scrollbar { width: 4px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 4px; }
  button { cursor: pointer; border: none; background: none; font-family: var(--body); }
  input, textarea, select { font-family: var(--body); }
  @keyframes fadeIn { from { opacity:0; transform:translateY(12px);} to { opacity:1; transform:translateY(0);} }
  @keyframes slideIn { from { opacity:0; transform:translateX(-20px);} to { opacity:1; transform:translateX(0);} }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.5} }
  @keyframes spin { to { transform: rotate(360deg); } }
  @keyframes shimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
  @keyframes glow { 0%,100%{box-shadow:0 0 20px rgba(59,130,246,0.2)} 50%{box-shadow:0 0 40px rgba(59,130,246,0.4)} }
  @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
  @keyframes counter { from{opacity:0;transform:scale(0.8)} to{opacity:1;transform:scale(1)} }
  .fade-in { animation: fadeIn 0.4s ease forwards; }
  .slide-in { animation: slideIn 0.3s ease forwards; }
  .glass {
    background: var(--surface);
    backdrop-filter: blur(20px);
    border: 1px solid var(--border);
  }
  .glass2 {
    background: var(--surface2);
    backdrop-filter: blur(20px);
    border: 1px solid var(--border2);
  }
  .hover-lift { transition: transform 0.2s ease, box-shadow 0.2s ease; }
  .hover-lift:hover { transform: translateY(-2px); box-shadow: var(--shadow); }
  .gradient-text {
    background: linear-gradient(135deg, #3b82f6, #8b5cf6, #06b6d4);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }
  .mesh-bg {
    background:
      radial-gradient(ellipse at 20% 50%, rgba(59,130,246,0.08) 0%, transparent 50%),
      radial-gradient(ellipse at 80% 20%, rgba(139,92,246,0.08) 0%, transparent 50%),
      radial-gradient(ellipse at 60% 80%, rgba(6,182,212,0.06) 0%, transparent 50%),
      var(--bg);
  }
  .skeleton {
    background: linear-gradient(90deg, var(--surface) 25%, var(--surface2) 50%, var(--surface) 75%);
    background-size: 200% 100%;
    animation: shimmer 1.5s infinite;
    border-radius: 8px;
  }
  .badge {
    display: inline-flex; align-items: center; gap: 4px;
    padding: 2px 10px; border-radius: 99px; font-size: 11px; font-weight: 600; letter-spacing: 0.04em;
  }
  .tag-urgent { background: rgba(239,68,68,0.15); color: #ef4444; border: 1px solid rgba(239,68,68,0.3); }
  .tag-high { background: rgba(249,115,22,0.15); color: #f97316; border: 1px solid rgba(249,115,22,0.3); }
  .tag-medium { background: rgba(245,158,11,0.15); color: #f59e0b; border: 1px solid rgba(245,158,11,0.3); }
  .tag-low { background: rgba(16,185,129,0.15); color: #10b981; border: 1px solid rgba(16,185,129,0.3); }
  .tag-todo { background: rgba(100,116,139,0.15); color: #94a3b8; border: 1px solid rgba(100,116,139,0.3); }
  .tag-progress { background: rgba(59,130,246,0.15); color: #3b82f6; border: 1px solid rgba(59,130,246,0.3); }
  .tag-done { background: rgba(16,185,129,0.15); color: #10b981; border: 1px solid rgba(16,185,129,0.3); }
  .tag-pm { background: rgba(139,92,246,0.15); color: #a78bfa; border: 1px solid rgba(139,92,246,0.3); }
  .tag-hr { background: rgba(6,182,212,0.15); color: #22d3ee; border: 1px solid rgba(6,182,212,0.3); }
  .tag-worker { background: rgba(59,130,246,0.15); color: #60a5fa; border: 1px solid rgba(59,130,246,0.3); }
  .progress-bar {
    height: 4px; border-radius: 99px; background: var(--surface2); overflow: hidden;
  }
  .progress-bar-fill { height: 100%; border-radius: 99px; transition: width 1s ease; }
  .nav-item {
    display: flex; align-items: center; gap: 10px; padding: 9px 14px;
    border-radius: 10px; font-size: 13.5px; font-weight: 500; color: var(--text3);
    transition: all 0.2s ease; white-space: nowrap; text-decoration: none;
    font-family: var(--body);
  }
  .nav-item:hover { background: var(--surface2); color: var(--text2); }
  .nav-item.active { background: rgba(59,130,246,0.12); color: var(--accent); border: 1px solid rgba(59,130,246,0.2); }
  .card {
    background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius2);
    padding: 20px; transition: border-color 0.2s ease;
  }
  .card:hover { border-color: var(--border2); }
  .btn {
    display: inline-flex; align-items: center; gap: 8px; padding: 9px 18px;
    border-radius: 10px; font-size: 13.5px; font-weight: 600; transition: all 0.2s ease;
    font-family: var(--body);
  }
  .btn-primary { background: var(--accent); color: #fff; }
  .btn-primary:hover { background: #2563eb; transform: translateY(-1px); }
  .btn-secondary { background: var(--surface2); color: var(--text); border: 1px solid var(--border2); }
  .btn-secondary:hover { background: var(--border); }
  .btn-ghost { color: var(--text2); padding: 8px 12px; }
  .btn-ghost:hover { background: var(--surface2); color: var(--text); }
  .btn-danger { background: rgba(239,68,68,0.15); color: #ef4444; border: 1px solid rgba(239,68,68,0.2); }
  .btn-danger:hover { background: rgba(239,68,68,0.25); }
  .input {
    width: 100%; background: var(--bg); border: 1px solid var(--border);
    border-radius: var(--radius); padding: 10px 14px; color: var(--text); font-size: 13.5px;
    outline: none; transition: border-color 0.2s ease;
  }
  .input:focus { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(59,130,246,0.1); }
  .input::placeholder { color: var(--text3); }
  .modal-overlay {
    position: fixed; inset: 0; background: rgba(0,0,0,0.7); backdrop-filter: blur(8px);
    z-index: 100; display: flex; align-items: center; justify-content: center; padding: 20px;
  }
  .modal { background: var(--bg2); border: 1px solid var(--border2); border-radius: 20px; padding: 28px; max-width: 520px; width: 100%; max-height: 90vh; overflow-y: auto; }
  .toast {
    position: fixed; bottom: 24px; right: 24px; z-index: 200;
    background: var(--bg2); border: 1px solid var(--border2);
    border-radius: 12px; padding: 14px 18px; display: flex; align-items: center; gap: 12px;
    box-shadow: var(--shadow); animation: slideIn 0.3s ease; min-width: 280px;
  }
  .kanban-col {
    background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius2);
    padding: 16px; min-height: 400px; width: 280px; flex-shrink: 0;
  }
  .kanban-card {
    background: var(--bg3); border: 1px solid var(--border); border-radius: 10px;
    padding: 14px; margin-bottom: 10px; cursor: grab; transition: all 0.2s ease;
  }
  .kanban-card:hover { border-color: var(--accent); transform: translateY(-2px); }
  .kanban-card.dragging { opacity: 0.5; transform: rotate(2deg); cursor: grabbing; }
  .stat-card {
    background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius2);
    padding: 22px; position: relative; overflow: hidden; transition: border-color 0.2s ease;
  }
  .stat-card::before {
    content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px;
    border-radius: 2px 2px 0 0;
  }
  .stat-card.blue::before { background: linear-gradient(90deg, var(--accent), var(--accent2)); }
  .stat-card.green::before { background: linear-gradient(90deg, var(--green), #34d399); }
  .stat-card.yellow::before { background: linear-gradient(90deg, var(--yellow), #fbbf24); }
  .stat-card.red::before { background: linear-gradient(90deg, var(--red), #f87171); }
  .stat-card.purple::before { background: linear-gradient(90deg, var(--accent3), #a78bfa); }
  .stat-card.cyan::before { background: linear-gradient(90deg, var(--cyan), #22d3ee); }
  .stat-card:hover { border-color: var(--border2); }
  .sidebar {
    width: 220px; min-height: 100vh; background: var(--bg2); border-right: 1px solid var(--border);
    display: flex; flex-direction: column; position: fixed; left: 0; top: 0; bottom: 0; z-index: 50;
    overflow-y: auto; transition: width 0.3s ease;
  }
  .sidebar.collapsed { width: 60px; }
  .main-content { margin-left: 220px; min-height: 100vh; transition: margin-left 0.3s ease; }
  .main-content.expanded { margin-left: 60px; }
  .topbar {
    background: rgba(13,19,32,0.95); backdrop-filter: blur(20px); border-bottom: 1px solid var(--border);
    padding: 0 24px; height: 60px; display: flex; align-items: center; gap: 16px;
    position: sticky; top: 0; z-index: 40;
  }
  .avatar {
    width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center;
    justify-content: center; font-size: 12px; font-weight: 700; flex-shrink: 0; font-family: var(--font);
  }
  .page { padding: 24px; animation: fadeIn 0.3s ease; }
  .section-title { font-family: var(--font); font-size: 22px; font-weight: 700; color: var(--text); }
  .section-sub { font-size: 13.5px; color: var(--text3); margin-top: 4px; }
  .table { width: 100%; border-collapse: collapse; }
  .table th { text-align: left; padding: 10px 14px; font-size: 11px; font-weight: 600; letter-spacing: 0.08em; color: var(--text3); text-transform: uppercase; border-bottom: 1px solid var(--border); }
  .table td { padding: 12px 14px; font-size: 13.5px; border-bottom: 1px solid var(--border); vertical-align: middle; }
  .table tr:last-child td { border-bottom: none; }
  .table tr:hover td { background: var(--surface); }
  .tab { padding: 8px 16px; border-radius: 8px; font-size: 13px; font-weight: 500; color: var(--text3); transition: all 0.2s; }
  .tab.active { background: var(--accent); color: #fff; }
  .tab:hover:not(.active) { background: var(--surface2); color: var(--text2); }
  @keyframes chartBar { from { transform: scaleY(0); transform-origin: bottom; } to { transform: scaleY(1); transform-origin: bottom; } }
  .chart-bar { animation: chartBar 0.8s ease forwards; }
`;
document.head.appendChild(style);

// ─── Data ─────────────────────────────────────────────────────────────────────
const USERS = [
  { id: 1, name: "Alex Morgan", email: "manager@company.com", role: "MAIN_PROJECT_MANAGER", avatar: "AM", color: "#6366f1" },
  { id: 2, name: "Sarah Chen", email: "hr@company.com", role: "HR", avatar: "SC", color: "#06b6d4" },
  { id: 3, name: "Marcus Lee", email: "marcus@company.com", role: "WORKER", avatar: "ML", color: "#10b981" },
  { id: 4, name: "Priya Patel", email: "priya@company.com", role: "WORKER", avatar: "PP", color: "#f59e0b" },
  { id: 5, name: "Jordan Kim", email: "jordan@company.com", role: "WORKER", avatar: "JK", color: "#ef4444" },
  { id: 6, name: "Elena Ruiz", email: "elena@company.com", role: "WORKER", avatar: "ER", color: "#8b5cf6" },
];

const PROJECTS_DATA = [
  { id: 1, name: "Nexus Platform v2.0", client: "TechCorp Inc.", status: "In Progress", priority: "high", progress: 72, deadline: "2025-06-15", team: [1,3,4], budget: "$48,000", tasks: 24, completed: 17 },
  { id: 2, name: "E-Commerce Redesign", client: "ShopFlow Ltd.", status: "In Progress", priority: "urgent", progress: 45, deadline: "2025-05-30", team: [3,5,6], budget: "$32,000", tasks: 18, completed: 8 },
  { id: 3, name: "Analytics Dashboard", client: "DataViz Co.", status: "Completed", priority: "medium", progress: 100, deadline: "2025-04-20", team: [4,6], budget: "$22,000", tasks: 15, completed: 15 },
  { id: 4, name: "Mobile App MVP", client: "StartupXYZ", status: "To Do", priority: "high", progress: 12, deadline: "2025-07-01", team: [3,4,5], budget: "$65,000", tasks: 31, completed: 4 },
  { id: 5, name: "Security Audit", client: "FinanceBank", status: "In Progress", priority: "urgent", progress: 60, deadline: "2025-05-25", team: [5,6], budget: "$18,000", tasks: 10, completed: 6 },
  { id: 6, name: "CRM Integration", client: "SalesForce Pro", status: "To Do", priority: "low", progress: 5, deadline: "2025-08-10", team: [3,6], budget: "$29,000", tasks: 22, completed: 1 },
];

const TASKS_DATA = [
  { id: 1, title: "Design system components", project: "Nexus Platform v2.0", assignee: 3, status: "In Progress", priority: "high", due: "2025-05-18", hours: 8, comments: 3 },
  { id: 2, title: "API authentication flow", project: "Nexus Platform v2.0", assignee: 4, status: "Completed", priority: "urgent", due: "2025-05-10", hours: 12, comments: 5 },
  { id: 3, title: "Product page redesign", project: "E-Commerce Redesign", assignee: 5, status: "To Do", priority: "medium", due: "2025-05-22", hours: 6, comments: 1 },
  { id: 4, title: "Payment gateway integration", project: "E-Commerce Redesign", assignee: 3, status: "In Progress", priority: "urgent", due: "2025-05-20", hours: 16, comments: 7 },
  { id: 5, title: "User behavior analytics", project: "Analytics Dashboard", assignee: 6, status: "Completed", priority: "high", due: "2025-04-15", hours: 10, comments: 2 },
  { id: 6, title: "Mobile navigation UX", project: "Mobile App MVP", assignee: 4, status: "To Do", priority: "medium", due: "2025-06-10", hours: 5, comments: 0 },
  { id: 7, title: "Vulnerability assessment", project: "Security Audit", assignee: 5, status: "In Progress", priority: "urgent", due: "2025-05-23", hours: 20, comments: 4 },
  { id: 8, title: "Database optimization", project: "Nexus Platform v2.0", assignee: 6, status: "To Do", priority: "low", due: "2025-05-28", hours: 8, comments: 1 },
];

const TIMELOGS = [
  { id: 1, user: 3, date: "2025-05-10", hours: 8.5, project: "Nexus Platform v2.0", task: "Design system components", overtime: false },
  { id: 2, user: 4, date: "2025-05-10", hours: 9.5, project: "E-Commerce Redesign", task: "Product page redesign", overtime: true },
  { id: 3, user: 5, date: "2025-05-10", hours: 7.0, project: "Security Audit", task: "Vulnerability assessment", overtime: false },
  { id: 4, user: 6, date: "2025-05-10", hours: 8.0, project: "Analytics Dashboard", task: "User behavior analytics", overtime: false },
  { id: 5, user: 3, date: "2025-05-09", hours: 8.0, project: "Nexus Platform v2.0", task: "Design system components", overtime: false },
  { id: 6, user: 4, date: "2025-05-09", hours: 10.5, project: "E-Commerce Redesign", task: "Payment gateway", overtime: true },
];

const NOTIFICATIONS_DATA = [
  { id: 1, type: "task", message: "Task 'API authentication flow' marked complete", time: "2m ago", read: false, icon: "✓" },
  { id: 2, type: "deadline", message: "Security Audit deadline in 2 days", time: "1h ago", read: false, icon: "⚠" },
  { id: 3, type: "comment", message: "Marcus left a comment on Payment gateway", time: "3h ago", read: true, icon: "💬" },
  { id: 4, type: "assign", message: "Jordan assigned to Vulnerability assessment", time: "5h ago", read: true, icon: "👤" },
  { id: 5, type: "task", message: "New task added to Mobile App MVP", time: "1d ago", read: true, icon: "📋" },
];

// ─── Mini Components ──────────────────────────────────────────────────────────
const Icon = ({ name, size = 16, color }) => {
  const icons = {
    dashboard: "M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z",
    projects: "M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z",
    tasks: "M9 11H7v2h2v-2zm4 0h-2v2h2v-2zm4 0h-2v2h2v-2zm2-7h-1V2h-2v2H8V2H6v2H5c-1.11 0-1.99.9-1.99 2L3 20c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V9h14v11z",
    workers: "M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z",
    analytics: "M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z",
    kanban: "M4 6h4v12H4zm6 0h4v12h-4zm6 0h4v12h-4z",
    hr: "M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z",
    payroll: "M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z",
    notifications: "M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.63-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.64 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z",
    settings: "M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.57 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z",
    requirements: "M9 5H7c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2h-2c0-1.1-.9-2-2-2s-2 .9-2 2zm2 0c0-.55.45-1 1-1s1 .45 1 1v1H11V5zm1 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm6 10H6v-.57c0-.81.48-1.53 1.22-1.85C8.31 15.23 9.64 15 12 15c2.36 0 3.69.23 4.78.58.74.32 1.22 1.04 1.22 1.85V18z",
    reports: "M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z",
    timer: "M15 1H9v2h6V1zm-4 13h2V8h-2v6zm8.03-6.61l1.42-1.42c-.43-.51-.9-.99-1.41-1.41l-1.42 1.42C16.07 4.74 14.12 4 12 4c-4.97 0-9 4.03-9 9s4.02 9 9 9 9-4.03 9-9c0-2.12-.74-4.07-1.97-5.61zM12 20c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7z",
    menu: "M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z",
    close: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z",
    plus: "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z",
    search: "M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z",
    check: "M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z",
    star: "M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z",
    fire: "M13.5.67s.74 2.65.74 4.8c0 2.06-1.35 3.73-3.41 3.73-2.07 0-3.63-1.67-3.63-3.73l.03-.36C5.21 7.51 4 10.62 4 14c0 4.42 3.58 8 8 8s8-3.58 8-8C20 8.61 17.41 3.8 13.5.67zM11.71 19c-1.78 0-3.22-1.4-3.22-3.14 0-1.62 1.05-2.76 2.81-3.12 1.77-.36 3.6-1.21 4.62-2.58.39 1.29.59 2.65.59 4.04 0 2.65-2.15 4.8-4.8 4.8z",
    clock: "M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z",
    alert: "M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z",
    google: "M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z",
    logout: "M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z",
    edit: "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z",
    trash: "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z",
    attach: "M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5c0-1.38 1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6H10v9.5c0 1.38 1.12 2.5 2.5 2.5s2.5-1.12 2.5-2.5V5c0-2.21-1.79-4-4-4S7 2.79 7 5v12.5c0 3.04 2.46 5.5 5.5 5.5s5.5-2.46 5.5-5.5V6h-1.5z",
    send: "M2.01 21L23 12 2.01 3 2 10l15 2-15 2z",
    filter: "M10 18h4v-2h-4v2zM3 6v2h18V6H3zm3 7h12v-2H6v2z",
    download: "M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z",
    user: "M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z",
    eye: "M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z",
    chevron: "M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z",
    globe: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z",
    briefcase: "M20 6h-2.18c.07-.44.18-.88.18-1.36C18 3.15 16.85 2 15.5 2h-7C7.15 2 6 3.15 6 4.64c0 .48.1.92.18 1.36H4c-1.1 0-1.99.9-1.99 2L2 19c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zM8 4.64C8 4.26 8.26 4 8.5 4h7c.24 0 .5.26.5.64 0 .48-.1.92-.18 1.36H8.18C8.1 5.56 8 5.12 8 4.64zm4 8.86L8.5 10H11V8h2v2h2.5L12 13.5z",
    lightning: "M7 2v11h3v9l7-12h-4l4-8z",
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color || "currentColor"} style={{ flexShrink: 0 }}>
      <path d={icons[name] || icons.star} />
    </svg>
  );
};

const Avatar = ({ user, size = 32 }) => (
  <div className="avatar" style={{ width: size, height: size, background: `${user?.color}22`, color: user?.color, fontSize: size * 0.35 }}>
    {user?.avatar}
  </div>
);

const Badge = ({ type, label }) => (
  <span className={`badge tag-${type}`}>{label}</span>
);

const ProgressBar = ({ value, color = "#3b82f6" }) => (
  <div className="progress-bar">
    <div className="progress-bar-fill" style={{ width: `${value}%`, background: color }} />
  </div>
);

const Toast = ({ message, type = "success", onClose }) => {
  useEffect(() => { const t = setTimeout(onClose, 3500); return () => clearTimeout(t); }, []);
  const colors = { success: "#10b981", error: "#ef4444", info: "#3b82f6", warning: "#f59e0b" };
  return (
    <div className="toast">
      <div style={{ width: 8, height: 8, borderRadius: "50%", background: colors[type], flexShrink: 0 }} />
      <span style={{ fontSize: 13.5, flex: 1 }}>{message}</span>
      <button className="btn-ghost btn" onClick={onClose} style={{ padding: "4px 8px" }}>✕</button>
    </div>
  );
};

// ─── Mini Chart Components ────────────────────────────────────────────────────
const BarChart = ({ data, height = 120, color = "#3b82f6" }) => {
  const max = Math.max(...data.map(d => d.value));
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 6, height, paddingTop: 8 }}>
      {data.map((d, i) => (
        <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
          <div style={{ width: "100%", height: `${(d.value / max) * 85}%`, background: `linear-gradient(to top, ${color}, ${color}88)`, borderRadius: "4px 4px 0 0", minHeight: 4, animationDelay: `${i * 0.1}s` }} className="chart-bar" />
          <span style={{ fontSize: 10, color: "var(--text3)", whiteSpace: "nowrap" }}>{d.label}</span>
        </div>
      ))}
    </div>
  );
};

const LineChart = ({ data, height = 80, color = "#6366f1" }) => {
  const max = Math.max(...data.map(d => d.value));
  const min = Math.min(...data.map(d => d.value));
  const w = 300, h = height;
  const pts = data.map((d, i) => ({
    x: (i / (data.length - 1)) * w,
    y: h - ((d.value - min) / (max - min || 1)) * (h - 16) - 8
  }));
  const path = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p.x},${p.y}`).join(" ");
  const area = `${path} L${w},${h} L0,${h} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} style={{ width: "100%", height }} preserveAspectRatio="none">
      <defs>
        <linearGradient id={`lg-${color.replace("#","")}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0.02" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#lg-${color.replace("#","")})`} />
      <path d={path} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      {pts.map((p, i) => <circle key={i} cx={p.x} cy={p.y} r="3.5" fill={color} />)}
    </svg>
  );
};

const DonutChart = ({ value, color = "#3b82f6", size = 80, label }) => {
  const r = 30, c = 2 * Math.PI * r;
  return (
    <div style={{ position: "relative", width: size, height: size }}>
      <svg viewBox="0 0 80 80" style={{ width: size, height: size, transform: "rotate(-90deg)" }}>
        <circle cx="40" cy="40" r={r} fill="none" stroke="var(--surface2)" strokeWidth="8" />
        <circle cx="40" cy="40" r={r} fill="none" stroke={color} strokeWidth="8"
          strokeDasharray={c} strokeDashoffset={c * (1 - value / 100)}
          strokeLinecap="round" style={{ transition: "stroke-dashoffset 1s ease" }} />
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
        <span style={{ fontSize: size * 0.22, fontWeight: 700, fontFamily: "var(--font)", color: "var(--text)" }}>{value}%</span>
        {label && <span style={{ fontSize: size * 0.14, color: "var(--text3)" }}>{label}</span>}
      </div>
    </div>
  );
};

// ─── Landing Page ─────────────────────────────────────────────────────────────
const Landing = ({ onLogin }) => {
  const [hovered, setHovered] = useState(null);
  const features = [
    { icon: "kanban", title: "Smart Kanban", desc: "Drag-and-drop task management with real-time updates across your team." },
    { icon: "analytics", title: "Deep Analytics", desc: "Actionable insights with beautiful charts and performance reports." },
    { icon: "timer", title: "Time Tracking", desc: "Precision timers with overtime alerts and automated payroll reports." },
    { icon: "workers", title: "Team Management", desc: "Role-based access, workload balancing, and HR payroll automation." },
    { icon: "notifications", title: "Smart Alerts", desc: "Deadline reminders, assignment notifications, and completion alerts." },
    { icon: "hr", title: "Security", desc: "Enterprise-grade auth with Google OAuth, JWT, and RBAC controls." },
  ];
  const stats = [
    { value: "12K+", label: "Active Teams" },
    { value: "99.9%", label: "Uptime SLA" },
    { value: "500K+", label: "Tasks Tracked" },
    { value: "4.9★", label: "User Rating" },
  ];
  return (
    <div className="mesh-bg" style={{ minHeight: "100vh", fontFamily: "var(--body)" }}>
      {/* Nav */}
      <nav style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "20px 60px", borderBottom: "1px solid var(--border)", backdropFilter: "blur(20px)", position: "sticky", top: 0, zIndex: 50, background: "rgba(8,12,20,0.8)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 34, height: 34, background: "linear-gradient(135deg, #3b82f6, #6366f1)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Icon name="lightning" size={18} color="#fff" />
          </div>
          <span style={{ fontFamily: "var(--font)", fontSize: 18, fontWeight: 800, letterSpacing: "-0.02em" }}>FlowNex</span>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          {["Features","Pricing","About","Contact"].map(p => (
            <button key={p} className="btn btn-ghost" style={{ fontSize: 13.5 }}>{p}</button>
          ))}
        </div>
        <button className="btn btn-primary" onClick={onLogin}>Get Started →</button>
      </nav>

      {/* Hero */}
      <div style={{ textAlign: "center", padding: "100px 40px 80px", maxWidth: 900, margin: "0 auto" }}>
        <div className="badge tag-progress" style={{ marginBottom: 24, display: "inline-flex" }}>
          <Icon name="lightning" size={11} /> NEW — Real-time collaboration now live
        </div>
        <h1 style={{ fontFamily: "var(--font)", fontSize: "clamp(42px,6vw,80px)", fontWeight: 800, lineHeight: 1.05, letterSpacing: "-0.04em", marginBottom: 24 }}>
          Project Management<br />
          <span className="gradient-text">Reimagined for Teams</span>
        </h1>
        <p style={{ fontSize: 18, color: "var(--text2)", maxWidth: 560, margin: "0 auto 40px", lineHeight: 1.7 }}>
          The all-in-one platform that unifies tasks, time tracking, HR payroll, and analytics — so your team ships faster.
        </p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
          <button className="btn btn-primary" onClick={onLogin} style={{ padding: "14px 32px", fontSize: 15, borderRadius: 12, animation: "glow 3s infinite" }}>
            <Icon name="google" size={18} />  Sign in with Google
          </button>
          <button className="btn btn-secondary" style={{ padding: "14px 28px", fontSize: 15, borderRadius: 12 }}>
            Watch Demo ▶
          </button>
        </div>
        <div style={{ marginTop: 20, color: "var(--text3)", fontSize: 13 }}>No credit card required · 14-day free trial</div>
      </div>

      {/* Stats */}
      <div style={{ display: "flex", justifyContent: "center", gap: 0, maxWidth: 700, margin: "0 auto 80px", background: "var(--bg2)", border: "1px solid var(--border)", borderRadius: 20, overflow: "hidden" }}>
        {stats.map((s, i) => (
          <div key={i} style={{ flex: 1, padding: "28px 20px", textAlign: "center", borderRight: i < stats.length - 1 ? "1px solid var(--border)" : "none" }}>
            <div style={{ fontFamily: "var(--font)", fontSize: 30, fontWeight: 800, color: "var(--text)" }}>{s.value}</div>
            <div style={{ fontSize: 12.5, color: "var(--text3)", marginTop: 4 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Features */}
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "0 40px 100px" }}>
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <h2 style={{ fontFamily: "var(--font)", fontSize: 36, fontWeight: 800, letterSpacing: "-0.02em" }}>Everything your team needs</h2>
          <p style={{ color: "var(--text2)", marginTop: 12, fontSize: 16 }}>Built for modern teams that move fast and ship often</p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 20 }}>
          {features.map((f, i) => (
            <div key={i} className="card hover-lift" style={{ padding: 28, cursor: "default", background: hovered === i ? "var(--bg3)" : "var(--bg2)" }}
              onMouseEnter={() => setHovered(i)} onMouseLeave={() => setHovered(null)}>
              <div style={{ width: 44, height: 44, background: "linear-gradient(135deg, rgba(59,130,246,0.2), rgba(139,92,246,0.2))", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16 }}>
                <Icon name={f.icon} size={20} color="#6366f1" />
              </div>
              <h3 style={{ fontFamily: "var(--font)", fontSize: 17, fontWeight: 700, marginBottom: 8 }}>{f.title}</h3>
              <p style={{ color: "var(--text2)", fontSize: 14, lineHeight: 1.6 }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div style={{ textAlign: "center", padding: "80px 40px", background: "linear-gradient(to bottom, transparent, rgba(59,130,246,0.05))", borderTop: "1px solid var(--border)" }}>
        <h2 style={{ fontFamily: "var(--font)", fontSize: 36, fontWeight: 800, marginBottom: 16 }}>Ready to level up?</h2>
        <p style={{ color: "var(--text2)", marginBottom: 32, fontSize: 16 }}>Join thousands of teams already using FlowNex</p>
        <button className="btn btn-primary" onClick={onLogin} style={{ padding: "14px 40px", fontSize: 15, borderRadius: 12 }}>
          Start Free Today →
        </button>
      </div>
    </div>
  );
};

// ─── Login Page ───────────────────────────────────────────────────────────────
const Login = ({ onLogin }) => {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("manager@company.com");
  const [pass, setPass] = useState("password");
  const [selectedUser, setSelectedUser] = useState(0);

  const demoUsers = [
    { label: "Project Manager", email: "manager@company.com", color: "#6366f1" },
    { label: "HR Manager", email: "hr@company.com", color: "#06b6d4" },
    { label: "Worker", email: "marcus@company.com", color: "#10b981" },
  ];

  const handleLogin = (userEmail) => {
    setLoading(true);
    setTimeout(() => {
      const u = USERS.find(u => u.email === (userEmail || email)) || USERS[0];
      onLogin(u);
    }, 1200);
  };

  return (
    <div className="mesh-bg" style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
      <div style={{ width: "100%", maxWidth: 420 }} className="fade-in">
        {/* Logo */}
        <div style={{ textAlign: "center", marginBottom: 40 }}>
          <div style={{ width: 56, height: 56, background: "linear-gradient(135deg, #3b82f6, #6366f1)", borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}>
            <Icon name="lightning" size={28} color="#fff" />
          </div>
          <h1 style={{ fontFamily: "var(--font)", fontSize: 26, fontWeight: 800 }}>Welcome to FlowNex</h1>
          <p style={{ color: "var(--text3)", fontSize: 14, marginTop: 6 }}>Sign in to your workspace</p>
        </div>

        <div className="card" style={{ padding: 32 }}>
          {/* Google */}
          <button className="btn btn-secondary" onClick={() => handleLogin(email)} style={{ width: "100%", justifyContent: "center", padding: "12px", fontSize: 14, marginBottom: 24, gap: 10 }} disabled={loading}>
            <Icon name="google" size={18} color="#4285F4" />
            {loading ? "Signing in..." : "Continue with Google"}
          </button>

          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 24 }}>
            <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
            <span style={{ fontSize: 12, color: "var(--text3)" }}>or email</span>
            <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 20 }}>
            <input className="input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" />
            <input className="input" type="password" value={pass} onChange={e => setPass(e.target.value)} placeholder="Password" />
          </div>

          <button className="btn btn-primary" onClick={() => handleLogin(email)} style={{ width: "100%", justifyContent: "center", padding: "12px", fontSize: 14 }} disabled={loading}>
            {loading ? <><span style={{ animation: "spin 1s linear infinite", display: "inline-block" }}>↻</span> Signing in...</> : "Sign In"}
          </button>

          {/* Demo switcher */}
          <div style={{ marginTop: 24, padding: 16, background: "var(--bg)", borderRadius: 12, border: "1px solid var(--border)" }}>
            <p style={{ fontSize: 11.5, color: "var(--text3)", marginBottom: 12, textAlign: "center", textTransform: "uppercase", letterSpacing: "0.06em" }}>Demo Accounts</p>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {demoUsers.map((u, i) => (
                <button key={i} onClick={() => { setEmail(u.email); handleLogin(u.email); }}
                  style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", borderRadius: 8, background: selectedUser === i ? "var(--surface2)" : "transparent", border: `1px solid ${selectedUser === i ? "var(--border2)" : "transparent"}`, cursor: "pointer", transition: "all 0.2s" }}
                  onMouseEnter={() => setSelectedUser(i)}>
                  <div style={{ width: 8, height: 8, borderRadius: "50%", background: u.color }} />
                  <span style={{ fontSize: 13, color: "var(--text2)", flex: 1, textAlign: "left" }}>{u.label}</span>
                  <span style={{ fontSize: 11, color: "var(--text3)" }}>{u.email}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <p style={{ textAlign: "center", color: "var(--text3)", fontSize: 12, marginTop: 20 }}>
          By continuing, you agree to our Terms & Privacy Policy
        </p>
      </div>
    </div>
  );
};

// ─── Sidebar ──────────────────────────────────────────────────────────────────
const Sidebar = ({ active, setActive, user, collapsed, onLogout }) => {
  const allNav = [
    { id: "dashboard", icon: "dashboard", label: "Dashboard", roles: ["MAIN_PROJECT_MANAGER", "HR", "WORKER"] },
    { id: "projects", icon: "briefcase", label: "Projects", roles: ["MAIN_PROJECT_MANAGER", "WORKER"] },
    { id: "requirements", icon: "requirements", label: "Requirements", roles: ["MAIN_PROJECT_MANAGER"] },
    { id: "tasks", icon: "tasks", label: "Tasks", roles: ["MAIN_PROJECT_MANAGER", "WORKER"] },
    { id: "kanban", icon: "kanban", label: "Kanban Board", roles: ["MAIN_PROJECT_MANAGER", "WORKER"] },
    { id: "timer", icon: "timer", label: "Time Tracker", roles: ["MAIN_PROJECT_MANAGER", "WORKER"] },
    { id: "workers", icon: "workers", label: "Workers", roles: ["MAIN_PROJECT_MANAGER", "HR"] },
    { id: "analytics", icon: "analytics", label: "Analytics", roles: ["MAIN_PROJECT_MANAGER"] },
    { id: "hr", icon: "hr", label: "HR Dashboard", roles: ["HR", "MAIN_PROJECT_MANAGER"] },
    { id: "payroll", icon: "payroll", label: "Payroll", roles: ["HR", "MAIN_PROJECT_MANAGER"] },
    { id: "reports", icon: "reports", label: "Reports", roles: ["MAIN_PROJECT_MANAGER", "HR"] },
    { id: "notifications", icon: "notifications", label: "Notifications", roles: ["MAIN_PROJECT_MANAGER", "HR", "WORKER"] },
    { id: "settings", icon: "settings", label: "Settings", roles: ["MAIN_PROJECT_MANAGER", "HR", "WORKER"] },
  ];
  const nav = allNav.filter(n => n.roles.includes(user?.role));
  const unread = NOTIFICATIONS_DATA.filter(n => !n.read).length;

  return (
    <div className="sidebar" style={{ width: collapsed ? 60 : 220 }}>
      {/* Logo */}
      <div style={{ padding: collapsed ? "20px 14px" : "20px 18px", display: "flex", alignItems: "center", gap: 10, borderBottom: "1px solid var(--border)", marginBottom: 8 }}>
        <div style={{ width: 32, height: 32, background: "linear-gradient(135deg, #3b82f6, #6366f1)", borderRadius: 9, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <Icon name="lightning" size={16} color="#fff" />
        </div>
        {!collapsed && <span style={{ fontFamily: "var(--font)", fontSize: 16, fontWeight: 800 }}>FlowNex</span>}
      </div>

      {/* Nav */}
      <div style={{ flex: 1, padding: "4px 8px", overflowY: "auto" }}>
        {nav.map(n => (
          <button key={n.id} className={`nav-item ${active === n.id ? "active" : ""}`}
            onClick={() => setActive(n.id)}
            style={{ width: "100%", justifyContent: collapsed ? "center" : "flex-start", position: "relative" }}
            title={collapsed ? n.label : ""}>
            <Icon name={n.icon} size={17} />
            {!collapsed && <span style={{ flex: 1 }}>{n.label}</span>}
            {!collapsed && n.id === "notifications" && unread > 0 && (
              <span style={{ background: "var(--red)", color: "#fff", fontSize: 10, fontWeight: 700, padding: "1px 6px", borderRadius: 99 }}>{unread}</span>
            )}
          </button>
        ))}
      </div>

      {/* User */}
      <div style={{ padding: collapsed ? "12px 8px" : "12px 10px", borderTop: "1px solid var(--border)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px", borderRadius: 10, cursor: "pointer" }} className="hover-lift">
          <Avatar user={user} size={30} />
          {!collapsed && (
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{user?.name}</div>
              <div style={{ fontSize: 11, color: "var(--text3)" }}>{user?.role === "MAIN_PROJECT_MANAGER" ? "PM" : user?.role}</div>
            </div>
          )}
          {!collapsed && <button className="btn btn-ghost" onClick={onLogout} style={{ padding: 6 }} title="Logout"><Icon name="logout" size={15} /></button>}
        </div>
      </div>
    </div>
  );
};

// ─── Dashboard Page ───────────────────────────────────────────────────────────
const Dashboard = ({ user }) => {
  const stats = [
    { label: "Total Projects", value: 6, sub: "+2 this month", color: "blue", icon: "briefcase", accent: "#3b82f6" },
    { label: "Active Workers", value: 4, sub: "2 on leave", color: "green", icon: "workers", accent: "#10b981" },
    { label: "Pending Tasks", value: 3, sub: "↑ 5 new today", color: "yellow", icon: "tasks", accent: "#f59e0b" },
    { label: "Overdue", value: 1, sub: "1 critical", color: "red", icon: "alert", accent: "#ef4444" },
    { label: "Completed", value: 17, sub: "+8 this week", color: "purple", icon: "check", accent: "#8b5cf6" },
    { label: "Hours Logged", value: "284h", sub: "this month", color: "cyan", icon: "clock", accent: "#06b6d4" },
  ];
  const weekData = [
    { label: "Mon", value: 42 }, { label: "Tue", value: 58 }, { label: "Wed", value: 35 },
    { label: "Thu", value: 71 }, { label: "Fri", value: 63 }, { label: "Sat", value: 28 }, { label: "Sun", value: 15 },
  ];
  const prodData = [
    { label: "W1", value: 65 }, { label: "W2", value: 72 }, { label: "W3", value: 68 }, { label: "W4", value: 84 },
  ];

  return (
    <div className="page">
      <div style={{ marginBottom: 28 }}>
        <h1 className="section-title">Good morning, {user?.name?.split(" ")[0]} 👋</h1>
        <p className="section-sub">Here's what's happening with your team today</p>
      </div>

      {/* Stats grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16, marginBottom: 28 }}>
        {stats.map((s, i) => (
          <div key={i} className={`stat-card ${s.color}`} style={{ animationDelay: `${i * 0.08}s` }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
              <Icon name={s.icon} size={18} color={s.accent} />
              <span style={{ fontSize: 11, color: "var(--text3)" }}>↑</span>
            </div>
            <div style={{ fontFamily: "var(--font)", fontSize: 30, fontWeight: 800, color: "var(--text)", marginBottom: 4 }}>{s.value}</div>
            <div style={{ fontSize: 13, fontWeight: 500, color: "var(--text2)" }}>{s.label}</div>
            <div style={{ fontSize: 11.5, color: "var(--text3)", marginTop: 2 }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 20, marginBottom: 28 }}>
        <div className="card">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
            <div>
              <h3 style={{ fontFamily: "var(--font)", fontSize: 15, fontWeight: 700 }}>Weekly Activity</h3>
              <p style={{ fontSize: 12, color: "var(--text3)", marginTop: 2 }}>Tasks completed per day</p>
            </div>
            <Badge type="progress" label="This Week" />
          </div>
          <BarChart data={weekData} height={140} color="#3b82f6" />
        </div>
        <div className="card">
          <h3 style={{ fontFamily: "var(--font)", fontSize: 15, fontWeight: 700, marginBottom: 4 }}>Productivity</h3>
          <p style={{ fontSize: 12, color: "var(--text3)", marginBottom: 20 }}>Monthly trend</p>
          <div style={{ display: "flex", justifyContent: "center", marginBottom: 16 }}>
            <DonutChart value={78} color="#6366f1" size={100} label="Score" />
          </div>
          <LineChart data={prodData} color="#6366f1" />
        </div>
      </div>

      {/* Bottom row */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        {/* Recent Projects */}
        <div className="card">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <h3 style={{ fontFamily: "var(--font)", fontSize: 15, fontWeight: 700 }}>Active Projects</h3>
            <Badge type="progress" label={`${PROJECTS_DATA.filter(p => p.status === "In Progress").length} running`} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {PROJECTS_DATA.filter(p => p.status === "In Progress").slice(0, 3).map((p, i) => (
              <div key={i} style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ fontSize: 13.5, fontWeight: 500 }}>{p.name}</span>
                  <span style={{ fontSize: 12, color: "var(--text3)" }}>{p.progress}%</span>
                </div>
                <ProgressBar value={p.progress} color={p.priority === "urgent" ? "#ef4444" : "#3b82f6"} />
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ fontSize: 11.5, color: "var(--text3)" }}>{p.client}</span>
                  <span style={{ fontSize: 11.5, color: "var(--text3)" }}>Due {p.deadline}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Notifications */}
        <div className="card">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <h3 style={{ fontFamily: "var(--font)", fontSize: 15, fontWeight: 700 }}>Notifications</h3>
            <span style={{ fontSize: 11, color: "var(--accent)", cursor: "pointer" }}>Mark all read</span>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {NOTIFICATIONS_DATA.slice(0, 4).map((n, i) => (
              <div key={i} style={{ display: "flex", gap: 10, padding: "10px 12px", borderRadius: 8, background: n.read ? "transparent" : "rgba(59,130,246,0.06)", border: `1px solid ${n.read ? "transparent" : "rgba(59,130,246,0.12)"}` }}>
                <div style={{ fontSize: 18 }}>{n.icon}</div>
                <div style={{ flex: 1 }}>
                  <p style={{ fontSize: 13, lineHeight: 1.4 }}>{n.message}</p>
                  <p style={{ fontSize: 11, color: "var(--text3)", marginTop: 3 }}>{n.time}</p>
                </div>
                {!n.read && <div style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--accent)", flexShrink: 0, marginTop: 6 }} />}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── Projects Page ────────────────────────────────────────────────────────────
const Projects = ({ showToast }) => {
  const [filter, setFilter] = useState("All");
  const [showModal, setShowModal] = useState(false);
  const [projects, setProjects] = useState(PROJECTS_DATA);
  const [form, setForm] = useState({ name: "", client: "", deadline: "", priority: "medium" });

  const filters = ["All", "In Progress", "Completed", "To Do"];
  const filtered = filter === "All" ? projects : projects.filter(p => p.status === filter);

  const priorityColor = { urgent: "#ef4444", high: "#f97316", medium: "#f59e0b", low: "#10b981" };
  const statusColor = { "In Progress": "#3b82f6", "Completed": "#10b981", "To Do": "#94a3b8" };

  const createProject = () => {
    if (!form.name) return;
    const newP = { id: projects.length + 1, ...form, status: "To Do", progress: 0, team: [1], budget: "$0", tasks: 0, completed: 0 };
    setProjects(prev => [...prev, newP]);
    setShowModal(false);
    setForm({ name: "", client: "", deadline: "", priority: "medium" });
    showToast("Project created successfully!", "success");
  };

  return (
    <div className="page">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
        <div>
          <h1 className="section-title">Projects</h1>
          <p className="section-sub">{projects.length} total projects</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          <Icon name="plus" size={16} /> New Project
        </button>
      </div>

      {/* Filters */}
      <div style={{ display: "flex", gap: 6, marginBottom: 20, flexWrap: "wrap" }}>
        {filters.map(f => (
          <button key={f} className={`tab ${filter === f ? "active" : ""}`} onClick={() => setFilter(f)}>{f}</button>
        ))}
      </div>

      {/* Grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 20 }}>
        {filtered.map((p, i) => (
          <div key={p.id} className="card hover-lift" style={{ cursor: "pointer" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
              <div>
                <h3 style={{ fontFamily: "var(--font)", fontSize: 15, fontWeight: 700, marginBottom: 4 }}>{p.name}</h3>
                <p style={{ fontSize: 12.5, color: "var(--text3)" }}>{p.client}</p>
              </div>
              <Badge type={p.priority} label={p.priority} />
            </div>

            <div style={{ marginBottom: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <span style={{ fontSize: 12, color: "var(--text3)" }}>Progress</span>
                <span style={{ fontSize: 12, fontWeight: 600 }}>{p.progress}%</span>
              </div>
              <ProgressBar value={p.progress} color={p.progress === 100 ? "#10b981" : "#3b82f6"} />
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ display: "flex", gap: -4 }}>
                {p.team.slice(0, 3).map(uid => {
                  const u = USERS.find(u => u.id === uid);
                  return u ? <Avatar key={uid} user={u} size={24} /> : null;
                })}
              </div>
              <div style={{ display: "flex", gap: 12, fontSize: 12, color: "var(--text3)" }}>
                <span><Icon name="tasks" size={12} /> {p.completed}/{p.tasks}</span>
                <span><Icon name="clock" size={12} /> {p.deadline}</span>
              </div>
            </div>

            <div style={{ marginTop: 12, paddingTop: 12, borderTop: "1px solid var(--border)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontSize: 12.5, color: statusColor[p.status], fontWeight: 600 }}>● {p.status}</span>
              <span style={{ fontSize: 12.5, color: "var(--text2)", fontWeight: 600 }}>{p.budget}</span>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal fade-in" onClick={e => e.stopPropagation()}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
              <h2 style={{ fontFamily: "var(--font)", fontSize: 18, fontWeight: 700 }}>New Project</h2>
              <button className="btn btn-ghost" onClick={() => setShowModal(false)}><Icon name="close" size={18} /></button>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              <div>
                <label style={{ fontSize: 12, color: "var(--text3)", marginBottom: 6, display: "block" }}>PROJECT NAME</label>
                <input className="input" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} placeholder="e.g. Website Redesign" />
              </div>
              <div>
                <label style={{ fontSize: 12, color: "var(--text3)", marginBottom: 6, display: "block" }}>CLIENT</label>
                <input className="input" value={form.client} onChange={e => setForm(p => ({ ...p, client: e.target.value }))} placeholder="Client name" />
              </div>
              <div>
                <label style={{ fontSize: 12, color: "var(--text3)", marginBottom: 6, display: "block" }}>DEADLINE</label>
                <input className="input" type="date" value={form.deadline} onChange={e => setForm(p => ({ ...p, deadline: e.target.value }))} />
              </div>
              <div>
                <label style={{ fontSize: 12, color: "var(--text3)", marginBottom: 6, display: "block" }}>PRIORITY</label>
                <select className="input" value={form.priority} onChange={e => setForm(p => ({ ...p, priority: e.target.value }))}>
                  {["urgent","high","medium","low"].map(v => <option key={v} value={v}>{v.charAt(0).toUpperCase() + v.slice(1)}</option>)}
                </select>
              </div>
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 24 }}>
              <button className="btn btn-secondary" onClick={() => setShowModal(false)} style={{ flex: 1, justifyContent: "center" }}>Cancel</button>
              <button className="btn btn-primary" onClick={createProject} style={{ flex: 1, justifyContent: "center" }}>Create Project</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ─── Tasks Page ───────────────────────────────────────────────────────────────
const Tasks = ({ user, showToast }) => {
  const [tasks, setTasks] = useState(TASKS_DATA);
  const [filter, setFilter] = useState("All");
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ title: "", project: "", assignee: 3, priority: "medium", due: "" });

  const filtered = filter === "All" ? tasks : tasks.filter(t => t.status === filter);

  const statusOpts = ["All", "To Do", "In Progress", "Completed"];

  const completeTask = (id) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, status: "Completed" } : t));
    showToast("Task marked complete!", "success");
  };

  return (
    <div className="page">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
        <div>
          <h1 className="section-title">Tasks</h1>
          <p className="section-sub">{tasks.length} total tasks</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          <Icon name="plus" size={16} /> New Task
        </button>
      </div>

      <div style={{ display: "flex", gap: 6, marginBottom: 20 }}>
        {statusOpts.map(f => (
          <button key={f} className={`tab ${filter === f ? "active" : ""}`} onClick={() => setFilter(f)}>{f}</button>
        ))}
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <table className="table">
          <thead>
            <tr>
              <th>Task</th><th>Project</th><th>Assignee</th><th>Priority</th><th>Status</th><th>Due</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(t => {
              const assignee = USERS.find(u => u.id === t.assignee);
              return (
                <tr key={t.id}>
                  <td>
                    <div style={{ fontWeight: 500, fontSize: 13.5 }}>{t.title}</div>
                    <div style={{ fontSize: 11.5, color: "var(--text3)", marginTop: 2 }}>{t.hours}h estimated</div>
                  </td>
                  <td style={{ color: "var(--text2)", fontSize: 13 }}>{t.project}</td>
                  <td>
                    <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                      <Avatar user={assignee} size={24} />
                      <span style={{ fontSize: 13 }}>{assignee?.name?.split(" ")[0]}</span>
                    </div>
                  </td>
                  <td><Badge type={t.priority} label={t.priority} /></td>
                  <td>
                    <span className={`badge tag-${t.status === "To Do" ? "todo" : t.status === "In Progress" ? "progress" : "done"}`}>
                      {t.status}
                    </span>
                  </td>
                  <td style={{ fontSize: 13, color: "var(--text2)" }}>{t.due}</td>
                  <td>
                    <div style={{ display: "flex", gap: 4 }}>
                      {t.status !== "Completed" && (
                        <button className="btn btn-ghost" onClick={() => completeTask(t.id)} style={{ padding: "5px 8px", color: "var(--green)" }} title="Mark complete">
                          <Icon name="check" size={14} />
                        </button>
                      )}
                      <button className="btn btn-ghost" style={{ padding: "5px 8px" }}><Icon name="edit" size={14} /></button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal fade-in" onClick={e => e.stopPropagation()}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
              <h2 style={{ fontFamily: "var(--font)", fontSize: 18, fontWeight: 700 }}>Create Task</h2>
              <button className="btn btn-ghost" onClick={() => setShowModal(false)}><Icon name="close" size={18} /></button>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              <div>
                <label style={{ fontSize: 12, color: "var(--text3)", marginBottom: 6, display: "block" }}>TASK TITLE</label>
                <input className="input" value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} placeholder="Task description" />
              </div>
              <div>
                <label style={{ fontSize: 12, color: "var(--text3)", marginBottom: 6, display: "block" }}>PROJECT</label>
                <select className="input" value={form.project} onChange={e => setForm(p => ({ ...p, project: e.target.value }))}>
                  <option value="">Select project...</option>
                  {PROJECTS_DATA.map(p => <option key={p.id} value={p.name}>{p.name}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize: 12, color: "var(--text3)", marginBottom: 6, display: "block" }}>ASSIGN TO</label>
                <select className="input" value={form.assignee} onChange={e => setForm(p => ({ ...p, assignee: +e.target.value }))}>
                  {USERS.filter(u => u.role === "WORKER").map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                </select>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <div>
                  <label style={{ fontSize: 12, color: "var(--text3)", marginBottom: 6, display: "block" }}>PRIORITY</label>
                  <select className="input" value={form.priority} onChange={e => setForm(p => ({ ...p, priority: e.target.value }))}>
                    {["urgent","high","medium","low"].map(v => <option key={v} value={v}>{v.charAt(0).toUpperCase() + v.slice(1)}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "var(--text3)", marginBottom: 6, display: "block" }}>DUE DATE</label>
                  <input className="input" type="date" value={form.due} onChange={e => setForm(p => ({ ...p, due: e.target.value }))} />
                </div>
              </div>
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 24 }}>
              <button className="btn btn-secondary" onClick={() => setShowModal(false)} style={{ flex: 1, justifyContent: "center" }}>Cancel</button>
              <button className="btn btn-primary" onClick={() => {
                if (!form.title) return;
                setTasks(prev => [...prev, { id: prev.length + 1, ...form, status: "To Do", hours: 4, comments: 0 }]);
                setShowModal(false);
                showToast("Task created!", "success");
              }} style={{ flex: 1, justifyContent: "center" }}>Create Task</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ─── Kanban Page ──────────────────────────────────────────────────────────────
const Kanban = ({ showToast }) => {
  const [columns, setColumns] = useState({
    "To Do": TASKS_DATA.filter(t => t.status === "To Do"),
    "In Progress": TASKS_DATA.filter(t => t.status === "In Progress"),
    "Completed": TASKS_DATA.filter(t => t.status === "Completed"),
  });
  const [dragging, setDragging] = useState(null);
  const [dragOver, setDragOver] = useState(null);

  const colColors = { "To Do": "#64748b", "In Progress": "#3b82f6", "Completed": "#10b981" };
  const colIcons = { "To Do": "📋", "In Progress": "⚡", "Completed": "✅" };

  const onDragStart = (task, col) => setDragging({ task, col });
  const onDragOver = (e, col) => { e.preventDefault(); setDragOver(col); };
  const onDrop = (e, targetCol) => {
    e.preventDefault();
    if (!dragging || dragging.col === targetCol) { setDragging(null); setDragOver(null); return; }
    setColumns(prev => {
      const src = prev[dragging.col].filter(t => t.id !== dragging.task.id);
      const dst = [...prev[targetCol], { ...dragging.task, status: targetCol }];
      return { ...prev, [dragging.col]: src, [targetCol]: dst };
    });
    showToast(`Task moved to ${targetCol}`, "info");
    setDragging(null); setDragOver(null);
  };

  return (
    <div className="page">
      <div style={{ marginBottom: 24 }}>
        <h1 className="section-title">Kanban Board</h1>
        <p className="section-sub">Drag and drop tasks between columns</p>
      </div>
      <div style={{ display: "flex", gap: 20, overflowX: "auto", paddingBottom: 12 }}>
        {Object.entries(columns).map(([col, tasks]) => (
          <div key={col} className="kanban-col" style={{ borderTop: `3px solid ${colColors[col]}`, opacity: dragOver === col && dragging?.col !== col ? 0.8 : 1, transition: "opacity 0.2s" }}
            onDragOver={e => onDragOver(e, col)} onDrop={e => onDrop(e, col)}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span>{colIcons[col]}</span>
                <span style={{ fontFamily: "var(--font)", fontSize: 14, fontWeight: 700 }}>{col}</span>
              </div>
              <span style={{ background: colColors[col] + "22", color: colColors[col], fontSize: 11, fontWeight: 700, padding: "2px 8px", borderRadius: 99 }}>{tasks.length}</span>
            </div>
            <div>
              {tasks.map(t => {
                const assignee = USERS.find(u => u.id === t.assignee);
                return (
                  <div key={t.id} className={`kanban-card ${dragging?.task?.id === t.id ? "dragging" : ""}`}
                    draggable onDragStart={() => onDragStart(t, col)}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                      <Badge type={t.priority} label={t.priority} />
                      <span style={{ fontSize: 11, color: "var(--text3)" }}>{t.due}</span>
                    </div>
                    <p style={{ fontSize: 13.5, fontWeight: 500, marginBottom: 10, lineHeight: 1.4 }}>{t.title}</p>
                    <p style={{ fontSize: 11.5, color: "var(--text3)", marginBottom: 10 }}>{t.project}</p>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <Avatar user={assignee} size={20} />
                        <span style={{ fontSize: 11.5, color: "var(--text3)" }}>{assignee?.name?.split(" ")[0]}</span>
                      </div>
                      <div style={{ display: "flex", gap: 8, fontSize: 11.5, color: "var(--text3)" }}>
                        <span>💬 {t.comments}</span>
                        <span>⏱ {t.hours}h</span>
                      </div>
                    </div>
                  </div>
                );
              })}
              <button className="btn btn-ghost" style={{ width: "100%", justifyContent: "center", marginTop: 8, border: "1px dashed var(--border2)", borderRadius: 8 }}>
                <Icon name="plus" size={14} /> Add Task
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── Timer Page ───────────────────────────────────────────────────────────────
const Timer = ({ user, showToast }) => {
  const [running, setRunning] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [logs, setLogs] = useState(TIMELOGS.filter(l => l.user === user?.id || user?.role === "MAIN_PROJECT_MANAGER"));
  const [selectedProject, setSelectedProject] = useState(PROJECTS_DATA[0]?.name || "");
  const [selectedTask, setSelectedTask] = useState(TASKS_DATA[0]?.title || "");
  const timerRef = useRef(null);

  useEffect(() => {
    if (running) timerRef.current = setInterval(() => setSeconds(s => s + 1), 1000);
    else clearInterval(timerRef.current);
    return () => clearInterval(timerRef.current);
  }, [running]);

  const fmt = s => {
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  };

  const stop = () => {
    setRunning(false);
    if (seconds > 0) {
      const hrs = seconds / 3600;
      const newLog = { id: logs.length + 1, user: user?.id, date: new Date().toISOString().split("T")[0], hours: +hrs.toFixed(2), project: selectedProject, task: selectedTask, overtime: hrs > 8 };
      setLogs(prev => [newLog, ...prev]);
      showToast(`Logged ${fmt(seconds)}`, "success");
      setSeconds(0);
    }
  };

  const totalToday = logs.filter(l => l.date === new Date().toISOString().split("T")[0]).reduce((s, l) => s + l.hours, 0);
  const totalWeek = logs.reduce((s, l) => s + l.hours, 0);

  return (
    <div className="page">
      <div style={{ marginBottom: 24 }}>
        <h1 className="section-title">Time Tracker</h1>
        <p className="section-sub">Track your work hours in real-time</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginBottom: 28 }}>
        {/* Timer */}
        <div className="card" style={{ textAlign: "center", padding: 40 }}>
          <div style={{ fontFamily: "var(--font)", fontSize: 72, fontWeight: 800, letterSpacing: "-0.04em", color: running ? "var(--accent)" : "var(--text)", marginBottom: 8, fontVariantNumeric: "tabular-nums" }}>
            {fmt(seconds)}
          </div>
          <p style={{ color: "var(--text3)", fontSize: 13, marginBottom: 24 }}>
            {running ? "Timer running..." : seconds > 0 ? "Paused" : "Ready to start"}
          </p>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 24, textAlign: "left" }}>
            <div>
              <label style={{ fontSize: 11, color: "var(--text3)", marginBottom: 6, display: "block" }}>PROJECT</label>
              <select className="input" value={selectedProject} onChange={e => setSelectedProject(e.target.value)} style={{ fontSize: 12.5 }}>
                {PROJECTS_DATA.map(p => <option key={p.id} value={p.name}>{p.name}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, color: "var(--text3)", marginBottom: 6, display: "block" }}>TASK</label>
              <select className="input" value={selectedTask} onChange={e => setSelectedTask(e.target.value)} style={{ fontSize: 12.5 }}>
                {TASKS_DATA.map(t => <option key={t.id} value={t.title}>{t.title}</option>)}
              </select>
            </div>
          </div>

          <div style={{ display: "flex", gap: 10, justifyContent: "center" }}>
            {!running ? (
              <button className="btn btn-primary" onClick={() => setRunning(true)} style={{ padding: "12px 36px", fontSize: 15 }}>
                ▶ Start
              </button>
            ) : (
              <button className="btn btn-secondary" onClick={() => setRunning(false)} style={{ padding: "12px 36px", fontSize: 15 }}>
                ⏸ Pause
              </button>
            )}
            {seconds > 0 && (
              <button className="btn btn-danger" onClick={stop} style={{ padding: "12px 28px", fontSize: 15 }}>
                ■ Stop & Save
              </button>
            )}
          </div>

          {seconds > 3600 * 8 && (
            <div style={{ marginTop: 16, padding: "10px 14px", background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.3)", borderRadius: 8, display: "flex", alignItems: "center", gap: 8 }}>
              <Icon name="alert" size={16} color="#f59e0b" />
              <span style={{ fontSize: 12.5, color: "#f59e0b" }}>Overtime warning: Over 8 hours!</span>
            </div>
          )}
        </div>

        {/* Summary */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {[
            { label: "Today", value: `${totalToday.toFixed(1)}h`, sub: "of 8h target", color: "blue", progress: (totalToday / 8) * 100 },
            { label: "This Week", value: `${totalWeek.toFixed(1)}h`, sub: "total logged", color: "green", progress: (totalWeek / 40) * 100 },
          ].map((s, i) => (
            <div key={i} className={`stat-card ${s.color}`} style={{ padding: 24 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
                <span style={{ fontSize: 13, color: "var(--text3)" }}>{s.label}</span>
                <span style={{ fontFamily: "var(--font)", fontSize: 26, fontWeight: 800 }}>{s.value}</span>
              </div>
              <ProgressBar value={Math.min(s.progress, 100)} color={i === 0 ? "#3b82f6" : "#10b981"} />
              <p style={{ fontSize: 12, color: "var(--text3)", marginTop: 6 }}>{s.sub}</p>
            </div>
          ))}
          <div className="card" style={{ padding: 20, flex: 1 }}>
            <h4 style={{ fontFamily: "var(--font)", fontSize: 14, fontWeight: 700, marginBottom: 12 }}>Breakdown by Project</h4>
            {PROJECTS_DATA.slice(0, 3).map((p, i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                <span style={{ fontSize: 13, color: "var(--text2)" }}>{p.name}</span>
                <span style={{ fontSize: 12, fontWeight: 600 }}>{(Math.random() * 15 + 5).toFixed(1)}h</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Log table */}
      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--border)", display: "flex", justifyContent: "space-between" }}>
          <h3 style={{ fontFamily: "var(--font)", fontSize: 15, fontWeight: 700 }}>Time Log</h3>
          <button className="btn btn-ghost" style={{ fontSize: 12 }}><Icon name="download" size={14} /> Export</button>
        </div>
        <table className="table">
          <thead><tr><th>Date</th><th>Project</th><th>Task</th><th>Hours</th><th>Status</th></tr></thead>
          <tbody>
            {logs.slice(0, 8).map(l => {
              const u = USERS.find(u => u.id === l.user);
              return (
                <tr key={l.id}>
                  <td style={{ fontSize: 13, color: "var(--text2)" }}>{l.date}</td>
                  <td style={{ fontSize: 13 }}>{l.project}</td>
                  <td style={{ fontSize: 13, color: "var(--text2)" }}>{l.task}</td>
                  <td>
                    <span style={{ fontWeight: 600, color: l.overtime ? "#f59e0b" : "var(--text)" }}>{l.hours}h</span>
                    {l.overtime && <span className="badge tag-medium" style={{ marginLeft: 6 }}>OT</span>}
                  </td>
                  <td><span className="badge tag-done">Logged</span></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ─── Workers Page ─────────────────────────────────────────────────────────────
const Workers = ({ showToast }) => {
  const workers = USERS.filter(u => u.role === "WORKER");
  const workerStats = workers.map(w => ({
    ...w,
    tasks: TASKS_DATA.filter(t => t.assignee === w.id).length,
    completed: TASKS_DATA.filter(t => t.assignee === w.id && t.status === "Completed").length,
    hours: TIMELOGS.filter(l => l.user === w.id).reduce((s, l) => s + l.hours, 0),
    utilization: Math.floor(Math.random() * 30 + 60),
  }));

  return (
    <div className="page">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
        <div>
          <h1 className="section-title">Workers</h1>
          <p className="section-sub">{workers.length} team members</p>
        </div>
        <button className="btn btn-primary" onClick={() => showToast("Invite sent!", "success")}>
          <Icon name="plus" size={16} /> Invite Worker
        </button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 20 }}>
        {workerStats.map((w, i) => (
          <div key={i} className="card hover-lift">
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
              <Avatar user={w} size={44} />
              <div>
                <div style={{ fontFamily: "var(--font)", fontSize: 15, fontWeight: 700 }}>{w.name}</div>
                <div style={{ fontSize: 12, color: "var(--text3)" }}>{w.email}</div>
              </div>
            </div>
            <Badge type="worker" label="WORKER" />

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, margin: "16px 0" }}>
              {[
                { label: "Tasks", value: w.tasks },
                { label: "Done", value: w.completed },
                { label: "Hours", value: `${w.hours}h` },
                { label: "Util.", value: `${w.utilization}%` },
              ].map((s, j) => (
                <div key={j} style={{ background: "var(--bg)", borderRadius: 8, padding: "10px 12px", textAlign: "center" }}>
                  <div style={{ fontFamily: "var(--font)", fontSize: 18, fontWeight: 700 }}>{s.value}</div>
                  <div style={{ fontSize: 11, color: "var(--text3)", marginTop: 2 }}>{s.label}</div>
                </div>
              ))}
            </div>

            <div style={{ marginBottom: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                <span style={{ fontSize: 12, color: "var(--text3)" }}>Utilization</span>
                <span style={{ fontSize: 12, fontWeight: 600 }}>{w.utilization}%</span>
              </div>
              <ProgressBar value={w.utilization} color={w.utilization > 85 ? "#ef4444" : w.utilization > 70 ? "#f59e0b" : "#10b981"} />
            </div>

            <div style={{ display: "flex", gap: 8 }}>
              <button className="btn btn-secondary" style={{ flex: 1, justifyContent: "center", fontSize: 12 }}>
                <Icon name="eye" size={13} /> View
              </button>
              <button className="btn btn-ghost" style={{ padding: "8px 10px" }}>
                <Icon name="edit" size={14} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── Analytics Page ───────────────────────────────────────────────────────────
const Analytics = () => {
  const monthData = [
    { label: "Jan", value: 42 }, { label: "Feb", value: 58 }, { label: "Mar", value: 51 },
    { label: "Apr", value: 73 }, { label: "May", value: 88 }, { label: "Jun", value: 64 },
  ];
  const workers = USERS.filter(u => u.role === "WORKER");

  return (
    <div className="page">
      <div style={{ marginBottom: 24 }}>
        <h1 className="section-title">Analytics</h1>
        <p className="section-sub">Team performance and productivity insights</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 24 }}>
        {[
          { label: "Completion Rate", value: "78%", delta: "+12%", color: "#10b981" },
          { label: "Avg Hours/Day", value: "7.2h", delta: "+0.4h", color: "#3b82f6" },
          { label: "On-Time Delivery", value: "85%", delta: "-3%", color: "#f59e0b" },
          { label: "Team Velocity", value: "94pts", delta: "+8pts", color: "#6366f1" },
        ].map((s, i) => (
          <div key={i} className="stat-card blue" style={{ padding: 20 }}>
            <div style={{ fontSize: 12, color: "var(--text3)", marginBottom: 8 }}>{s.label}</div>
            <div style={{ fontFamily: "var(--font)", fontSize: 28, fontWeight: 800 }}>{s.value}</div>
            <div style={{ fontSize: 12, color: s.color, marginTop: 4 }}>{s.delta} vs last month</div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "3fr 2fr", gap: 20, marginBottom: 24 }}>
        <div className="card">
          <h3 style={{ fontFamily: "var(--font)", fontSize: 15, fontWeight: 700, marginBottom: 4 }}>Monthly Task Completion</h3>
          <p style={{ fontSize: 12, color: "var(--text3)", marginBottom: 20 }}>Tasks completed per month</p>
          <BarChart data={monthData} height={160} color="#6366f1" />
        </div>
        <div className="card">
          <h3 style={{ fontFamily: "var(--font)", fontSize: 15, fontWeight: 700, marginBottom: 16 }}>Project Status</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {[
              { label: "In Progress", count: 3, color: "#3b82f6", pct: 50 },
              { label: "Completed", count: 1, color: "#10b981", pct: 17 },
              { label: "To Do", count: 2, color: "#94a3b8", pct: 33 },
            ].map((s, i) => (
              <div key={i}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                  <span style={{ fontSize: 13 }}>{s.label}</span>
                  <span style={{ fontSize: 12, color: "var(--text3)" }}>{s.count} ({s.pct}%)</span>
                </div>
                <ProgressBar value={s.pct} color={s.color} />
              </div>
            ))}
          </div>
          <div style={{ marginTop: 20, display: "flex", justifyContent: "center" }}>
            <DonutChart value={78} color="#3b82f6" size={90} label="Health" />
          </div>
        </div>
      </div>

      {/* Worker utilization */}
      <div className="card">
        <h3 style={{ fontFamily: "var(--font)", fontSize: 15, fontWeight: 700, marginBottom: 20 }}>Worker Utilization</h3>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {workers.map((w, i) => {
            const util = [72, 88, 65, 91][i] || 75;
            return (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 14 }}>
                <Avatar user={w} size={32} />
                <div style={{ width: 120, fontSize: 13 }}>{w.name}</div>
                <div style={{ flex: 1 }}>
                  <ProgressBar value={util} color={util > 85 ? "#ef4444" : util > 70 ? "#f59e0b" : "#10b981"} />
                </div>
                <span style={{ width: 40, textAlign: "right", fontSize: 13, fontWeight: 600 }}>{util}%</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

// ─── HR Dashboard ─────────────────────────────────────────────────────────────
const HRDashboard = () => {
  const workers = USERS.filter(u => u.role === "WORKER");
  return (
    <div className="page">
      <div style={{ marginBottom: 24 }}>
        <h1 className="section-title">HR Dashboard</h1>
        <p className="section-sub">Employee management and attendance overview</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 24 }}>
        {[
          { label: "Total Employees", value: 6, color: "blue" },
          { label: "Present Today", value: 5, color: "green" },
          { label: "On Leave", value: 1, color: "yellow" },
          { label: "Overtime This Week", value: 2, color: "red" },
        ].map((s, i) => (
          <div key={i} className={`stat-card ${s.color}`} style={{ padding: 20 }}>
            <div style={{ fontFamily: "var(--font)", fontSize: 28, fontWeight: 800, marginBottom: 4 }}>{s.value}</div>
            <div style={{ fontSize: 13, color: "var(--text2)" }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--border)" }}>
          <h3 style={{ fontFamily: "var(--font)", fontSize: 15, fontWeight: 700 }}>Employee Overview</h3>
        </div>
        <table className="table">
          <thead><tr><th>Employee</th><th>Role</th><th>Dept</th><th>Hours This Week</th><th>Status</th><th>Performance</th></tr></thead>
          <tbody>
            {USERS.map((u, i) => {
              const hours = TIMELOGS.filter(l => l.user === u.id).reduce((s, l) => s + l.hours, 0);
              const perf = [92, 88, 95, 79, 85, 91][i];
              return (
                <tr key={u.id}>
                  <td>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <Avatar user={u} size={28} />
                      <div>
                        <div style={{ fontWeight: 500, fontSize: 13.5 }}>{u.name}</div>
                        <div style={{ fontSize: 11, color: "var(--text3)" }}>{u.email}</div>
                      </div>
                    </div>
                  </td>
                  <td><Badge type={u.role === "MAIN_PROJECT_MANAGER" ? "pm" : u.role === "HR" ? "hr" : "worker"} label={u.role === "MAIN_PROJECT_MANAGER" ? "PM" : u.role} /></td>
                  <td style={{ fontSize: 13, color: "var(--text2)" }}>Engineering</td>
                  <td>
                    <span style={{ fontWeight: 600 }}>{hours.toFixed(1)}h</span>
                    {hours > 40 && <span className="badge tag-medium" style={{ marginLeft: 6 }}>OT</span>}
                  </td>
                  <td><span className="badge tag-done">Active</span></td>
                  <td>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <ProgressBar value={perf} color={perf > 90 ? "#10b981" : perf > 75 ? "#3b82f6" : "#f59e0b"} />
                      <span style={{ fontSize: 12, width: 32, fontWeight: 600 }}>{perf}%</span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ─── Payroll Page ─────────────────────────────────────────────────────────────
const Payroll = ({ showToast }) => {
  const workers = USERS;
  const rates = { MAIN_PROJECT_MANAGER: 85, HR: 65, WORKER: 45 };
  const [period, setPeriod] = useState("May 2025");

  const payrollData = workers.map(u => {
    const hours = TIMELOGS.filter(l => l.user === u.id).reduce((s, l) => s + l.hours, 0) + Math.random() * 100 + 140;
    const rate = rates[u.role];
    const regular = Math.min(hours, 160) * rate;
    const ot = Math.max(0, hours - 160) * rate * 1.5;
    return { ...u, hours: +hours.toFixed(1), rate, regular: +regular.toFixed(2), overtime: +ot.toFixed(2), total: +(regular + ot).toFixed(2) };
  });

  const totalPayroll = payrollData.reduce((s, p) => s + p.total, 0);

  return (
    <div className="page">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
        <div>
          <h1 className="section-title">Payroll</h1>
          <p className="section-sub">{period} payroll summary</p>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <select className="input" value={period} onChange={e => setPeriod(e.target.value)} style={{ width: 150 }}>
            {["May 2025","April 2025","March 2025"].map(p => <option key={p} value={p}>{p}</option>)}
          </select>
          <button className="btn btn-primary" onClick={() => showToast("Payroll exported!", "success")}>
            <Icon name="download" size={16} /> Export
          </button>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 24 }}>
        {[
          { label: "Total Payroll", value: `$${totalPayroll.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`, color: "blue" },
          { label: "Regular Hours", value: `${payrollData.reduce((s, p) => s + Math.min(p.hours, 160), 0).toFixed(0)}h`, color: "green" },
          { label: "Overtime Hours", value: `${payrollData.reduce((s, p) => s + Math.max(0, p.hours - 160), 0).toFixed(0)}h`, color: "yellow" },
          { label: "Avg Salary", value: `$${(totalPayroll / workers.length).toFixed(0)}`, color: "purple" },
        ].map((s, i) => (
          <div key={i} className={`stat-card ${s.color}`} style={{ padding: 20 }}>
            <div style={{ fontFamily: "var(--font)", fontSize: 24, fontWeight: 800, marginBottom: 4 }}>{s.value}</div>
            <div style={{ fontSize: 13, color: "var(--text2)" }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--border)", display: "flex", justifyContent: "space-between" }}>
          <h3 style={{ fontFamily: "var(--font)", fontSize: 15, fontWeight: 700 }}>Payroll Breakdown</h3>
          <Badge type="progress" label={period} />
        </div>
        <table className="table">
          <thead><tr><th>Employee</th><th>Role</th><th>Hours</th><th>Rate/hr</th><th>Regular</th><th>Overtime</th><th>Total</th><th>Status</th></tr></thead>
          <tbody>
            {payrollData.map((p, i) => (
              <tr key={p.id}>
                <td>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <Avatar user={p} size={28} />
                    <span style={{ fontWeight: 500, fontSize: 13.5 }}>{p.name}</span>
                  </div>
                </td>
                <td><Badge type={p.role === "MAIN_PROJECT_MANAGER" ? "pm" : p.role === "HR" ? "hr" : "worker"} label={p.role === "MAIN_PROJECT_MANAGER" ? "PM" : p.role} /></td>
                <td style={{ fontSize: 13 }}>{p.hours}h</td>
                <td style={{ fontSize: 13, color: "var(--text2)" }}>${p.rate}/h</td>
                <td style={{ fontSize: 13 }}>${p.regular.toLocaleString()}</td>
                <td style={{ fontSize: 13, color: p.overtime > 0 ? "#f59e0b" : "var(--text3)" }}>${p.overtime.toLocaleString()}</td>
                <td><span style={{ fontFamily: "var(--font)", fontSize: 14, fontWeight: 700, color: "var(--green)" }}>${p.total.toLocaleString()}</span></td>
                <td><span className="badge tag-done">Processed</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ─── Requirements Page ────────────────────────────────────────────────────────
const Requirements = ({ showToast }) => {
  const [reqs, setReqs] = useState([
    { id: 1, title: "User Authentication Module", client: "TechCorp Inc.", priority: "urgent", status: "In Review", deadline: "2025-05-20", files: 3, comments: 5 },
    { id: 2, title: "Payment Integration Spec", client: "ShopFlow Ltd.", priority: "high", status: "Approved", deadline: "2025-05-25", files: 2, comments: 8 },
    { id: 3, title: "Reporting Dashboard Requirements", client: "DataViz Co.", priority: "medium", status: "Pending", deadline: "2025-06-01", files: 1, comments: 2 },
    { id: 4, title: "Mobile App Wireframes", client: "StartupXYZ", priority: "high", status: "In Review", deadline: "2025-06-10", files: 7, comments: 12 },
  ]);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ title: "", client: "", priority: "medium", deadline: "" });

  return (
    <div className="page">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
        <div>
          <h1 className="section-title">Requirements Hub</h1>
          <p className="section-sub">Client requirements and intake management</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          <Icon name="plus" size={16} /> New Requirement
        </button>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        {reqs.map((r, i) => (
          <div key={r.id} className="card hover-lift" style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 20, alignItems: "center" }}>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                <h3 style={{ fontFamily: "var(--font)", fontSize: 15, fontWeight: 700 }}>{r.title}</h3>
                <Badge type={r.priority} label={r.priority} />
                <span className={`badge tag-${r.status === "Approved" ? "done" : r.status === "In Review" ? "progress" : "todo"}`}>{r.status}</span>
              </div>
              <div style={{ display: "flex", gap: 16, fontSize: 12.5, color: "var(--text3)" }}>
                <span>📁 {r.client}</span>
                <span>📅 {r.deadline}</span>
                <span>📎 {r.files} files</span>
                <span>💬 {r.comments} comments</span>
              </div>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button className="btn btn-secondary" style={{ fontSize: 12 }}><Icon name="eye" size={13} /> View</button>
              <button className="btn btn-ghost"><Icon name="edit" size={14} /></button>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal fade-in" onClick={e => e.stopPropagation()}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
              <h2 style={{ fontFamily: "var(--font)", fontSize: 18, fontWeight: 700 }}>New Requirement</h2>
              <button className="btn btn-ghost" onClick={() => setShowModal(false)}><Icon name="close" size={18} /></button>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              <input className="input" placeholder="Requirement title" value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} />
              <input className="input" placeholder="Client name" value={form.client} onChange={e => setForm(p => ({ ...p, client: e.target.value }))} />
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <select className="input" value={form.priority} onChange={e => setForm(p => ({ ...p, priority: e.target.value }))}>
                  {["urgent","high","medium","low"].map(v => <option key={v} value={v}>{v}</option>)}
                </select>
                <input className="input" type="date" value={form.deadline} onChange={e => setForm(p => ({ ...p, deadline: e.target.value }))} />
              </div>
              <div style={{ border: "2px dashed var(--border2)", borderRadius: 10, padding: "24px", textAlign: "center" }}>
                <Icon name="attach" size={24} color="var(--text3)" />
                <p style={{ fontSize: 13, color: "var(--text3)", marginTop: 8 }}>Drop files or click to upload</p>
              </div>
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 24 }}>
              <button className="btn btn-secondary" onClick={() => setShowModal(false)} style={{ flex: 1, justifyContent: "center" }}>Cancel</button>
              <button className="btn btn-primary" onClick={() => {
                if (!form.title) return;
                setReqs(prev => [...prev, { id: prev.length + 1, ...form, status: "Pending", files: 0, comments: 0 }]);
                setShowModal(false);
                showToast("Requirement added!", "success");
              }} style={{ flex: 1, justifyContent: "center" }}>Submit</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ─── Notifications Page ───────────────────────────────────────────────────────
const Notifications = ({ showToast }) => {
  const [notes, setNotes] = useState(NOTIFICATIONS_DATA);
  const markAllRead = () => { setNotes(prev => prev.map(n => ({ ...n, read: true }))); showToast("All notifications read", "info"); };

  return (
    <div className="page">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
        <div>
          <h1 className="section-title">Notifications</h1>
          <p className="section-sub">{notes.filter(n => !n.read).length} unread</p>
        </div>
        <button className="btn btn-secondary" onClick={markAllRead}>Mark all read</button>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 10, maxWidth: 700 }}>
        {notes.map((n, i) => (
          <div key={n.id} className="card" style={{ display: "flex", alignItems: "flex-start", gap: 14, background: n.read ? "var(--bg2)" : "rgba(59,130,246,0.06)", borderColor: n.read ? "var(--border)" : "rgba(59,130,246,0.2)", cursor: "pointer" }}
            onClick={() => setNotes(prev => prev.map(x => x.id === n.id ? { ...x, read: true } : x))}>
            <div style={{ width: 36, height: 36, background: "var(--surface2)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>
              {n.icon}
            </div>
            <div style={{ flex: 1 }}>
              <p style={{ fontSize: 14, lineHeight: 1.4 }}>{n.message}</p>
              <p style={{ fontSize: 12, color: "var(--text3)", marginTop: 4 }}>{n.time}</p>
            </div>
            {!n.read && <div style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--accent)", marginTop: 8, flexShrink: 0 }} />}
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── Reports Page ─────────────────────────────────────────────────────────────
const Reports = ({ showToast }) => {
  const weekData = [
    { label: "Mon", value: 14 }, { label: "Tue", value: 18 }, { label: "Wed", value: 11 },
    { label: "Thu", value: 22 }, { label: "Fri", value: 19 }, { label: "Sat", value: 7 }, { label: "Sun", value: 3 },
  ];
  return (
    <div className="page">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
        <div>
          <h1 className="section-title">Reports</h1>
          <p className="section-sub">Performance and productivity reports</p>
        </div>
        <button className="btn btn-primary" onClick={() => showToast("Report exported as PDF!", "success")}>
          <Icon name="download" size={16} /> Export PDF
        </button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 20, marginBottom: 24 }}>
        <div className="card">
          <h3 style={{ fontFamily: "var(--font)", fontSize: 15, fontWeight: 700, marginBottom: 4 }}>Daily Task Completion</h3>
          <p style={{ fontSize: 12, color: "var(--text3)", marginBottom: 20 }}>This week</p>
          <BarChart data={weekData} height={160} color="#8b5cf6" />
        </div>
        <div className="card">
          <h3 style={{ fontFamily: "var(--font)", fontSize: 15, fontWeight: 700, marginBottom: 16 }}>Summary</h3>
          {[
            { label: "Total Tasks", value: TASKS_DATA.length },
            { label: "Completed", value: TASKS_DATA.filter(t => t.status === "Completed").length },
            { label: "In Progress", value: TASKS_DATA.filter(t => t.status === "In Progress").length },
            { label: "Overdue", value: 1 },
          ].map((s, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: i < 3 ? "1px solid var(--border)" : "none" }}>
              <span style={{ fontSize: 13.5, color: "var(--text2)" }}>{s.label}</span>
              <span style={{ fontFamily: "var(--font)", fontSize: 16, fontWeight: 700 }}>{s.value}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="card">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <h3 style={{ fontFamily: "var(--font)", fontSize: 15, fontWeight: 700 }}>Worker Performance Report</h3>
          <Badge type="progress" label="May 2025" />
        </div>
        <table className="table">
          <thead><tr><th>Worker</th><th>Tasks Assigned</th><th>Completed</th><th>Hours</th><th>Score</th></tr></thead>
          <tbody>
            {USERS.filter(u => u.role === "WORKER").map((w, i) => {
              const assigned = TASKS_DATA.filter(t => t.assignee === w.id).length;
              const done = TASKS_DATA.filter(t => t.assignee === w.id && t.status === "Completed").length;
              const hours = TIMELOGS.filter(l => l.user === w.id).reduce((s, l) => s + l.hours, 0);
              const score = Math.floor(Math.random() * 15 + 80);
              return (
                <tr key={w.id}>
                  <td>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <Avatar user={w} size={28} />
                      <span style={{ fontWeight: 500 }}>{w.name}</span>
                    </div>
                  </td>
                  <td style={{ fontSize: 13 }}>{assigned}</td>
                  <td style={{ fontSize: 13, color: "var(--green)" }}>{done}</td>
                  <td style={{ fontSize: 13 }}>{hours.toFixed(1)}h</td>
                  <td>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <ProgressBar value={score} color={score > 90 ? "#10b981" : "#3b82f6"} />
                      <span style={{ fontSize: 12, fontWeight: 600, width: 36 }}>{score}%</span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ─── Settings Page ────────────────────────────────────────────────────────────
const Settings = ({ user, showToast }) => {
  const [name, setName] = useState(user?.name || "");
  const [emailNotif, setEmailNotif] = useState(true);
  const [pushNotif, setPushNotif] = useState(true);
  const [darkMode, setDarkMode] = useState(true);

  const Toggle = ({ value, onChange }) => (
    <div onClick={() => onChange(!value)} style={{ width: 44, height: 24, borderRadius: 99, background: value ? "var(--accent)" : "var(--surface2)", cursor: "pointer", position: "relative", transition: "background 0.2s", border: "1px solid var(--border2)" }}>
      <div style={{ width: 18, height: 18, borderRadius: "50%", background: "#fff", position: "absolute", top: 2, left: value ? 22 : 2, transition: "left 0.2s", boxShadow: "0 1px 4px rgba(0,0,0,0.3)" }} />
    </div>
  );

  return (
    <div className="page" style={{ maxWidth: 640 }}>
      <div style={{ marginBottom: 24 }}>
        <h1 className="section-title">Settings</h1>
        <p className="section-sub">Manage your account preferences</p>
      </div>

      {[
        {
          title: "Profile", items: [
            <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 20 }}>
              <Avatar user={user} size={56} />
              <div>
                <div style={{ fontWeight: 600, fontSize: 15 }}>{user?.name}</div>
                <div style={{ fontSize: 13, color: "var(--text3)" }}>{user?.email}</div>
                <button className="btn btn-secondary" style={{ marginTop: 8, fontSize: 12, padding: "6px 12px" }}>Change Photo</button>
              </div>
            </div>,
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <div>
                <label style={{ fontSize: 12, color: "var(--text3)", marginBottom: 6, display: "block" }}>DISPLAY NAME</label>
                <input className="input" value={name} onChange={e => setName(e.target.value)} />
              </div>
              <div>
                <label style={{ fontSize: 12, color: "var(--text3)", marginBottom: 6, display: "block" }}>EMAIL</label>
                <input className="input" value={user?.email} readOnly style={{ opacity: 0.6 }} />
              </div>
            </div>
          ]
        },
        {
          title: "Notifications", items: [
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0" }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 500 }}>Email Notifications</div>
                <div style={{ fontSize: 12, color: "var(--text3)" }}>Receive task and deadline alerts</div>
              </div>
              <Toggle value={emailNotif} onChange={setEmailNotif} />
            </div>,
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0" }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 500 }}>Push Notifications</div>
                <div style={{ fontSize: 12, color: "var(--text3)" }}>Browser push alerts</div>
              </div>
              <Toggle value={pushNotif} onChange={setPushNotif} />
            </div>
          ]
        },
        {
          title: "Appearance", items: [
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0" }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 500 }}>Dark Mode</div>
                <div style={{ fontSize: 12, color: "var(--text3)" }}>Use dark color scheme</div>
              </div>
              <Toggle value={darkMode} onChange={setDarkMode} />
            </div>
          ]
        }
      ].map((section, i) => (
        <div key={i} className="card" style={{ marginBottom: 20 }}>
          <h3 style={{ fontFamily: "var(--font)", fontSize: 14, fontWeight: 700, marginBottom: 16, paddingBottom: 12, borderBottom: "1px solid var(--border)" }}>{section.title}</h3>
          {section.items.map((item, j) => <div key={j}>{item}</div>)}
        </div>
      ))}

      <button className="btn btn-primary" onClick={() => showToast("Settings saved!", "success")} style={{ padding: "11px 32px" }}>
        Save Changes
      </button>
    </div>
  );
};

// ─── App Shell ────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState("landing"); // landing | login | app
  const [user, setUser] = useState(null);
  const [activePage, setActivePage] = useState("dashboard");
  const [collapsed, setCollapsed] = useState(false);
  const [toast, setToast] = useState(null);

  const showToast = (message, type = "success") => setToast({ message, type, id: Date.now() });

  const handleLogin = (u) => {
    setUser(u);
    setScreen("app");
    setActivePage("dashboard");
    showToast(`Welcome back, ${u.name.split(" ")[0]}! 👋`, "success");
  };

  const handleLogout = () => { setUser(null); setScreen("landing"); };

  const renderPage = () => {
    const props = { user, showToast };
    switch (activePage) {
      case "dashboard": return <Dashboard {...props} />;
      case "projects": return <Projects {...props} />;
      case "requirements": return <Requirements {...props} />;
      case "tasks": return <Tasks {...props} />;
      case "kanban": return <Kanban {...props} />;
      case "timer": return <Timer {...props} />;
      case "workers": return <Workers {...props} />;
      case "analytics": return <Analytics {...props} />;
      case "hr": return <HRDashboard {...props} />;
      case "payroll": return <Payroll {...props} />;
      case "reports": return <Reports {...props} />;
      case "notifications": return <Notifications {...props} />;
      case "settings": return <Settings {...props} />;
      default: return <Dashboard {...props} />;
    }
  };

  if (screen === "landing") return (
    <>
      <Landing onLogin={() => setScreen("login")} />
      {toast && <Toast key={toast.id} message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </>
  );

  if (screen === "login") return (
    <>
      <Login onLogin={handleLogin} />
      {toast && <Toast key={toast.id} message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </>
  );

  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      <Sidebar active={activePage} setActive={setActivePage} user={user} collapsed={collapsed} onLogout={handleLogout} />

      <div className="main-content" style={{ marginLeft: collapsed ? 60 : 220, flex: 1 }}>
        {/* Topbar */}
        <div className="topbar">
          <button className="btn btn-ghost" onClick={() => setCollapsed(c => !c)} style={{ padding: 8 }}>
            <Icon name="menu" size={18} />
          </button>
          <div style={{ flex: 1, position: "relative", maxWidth: 360 }}>
            <Icon name="search" size={15} color="var(--text3)" />
            <input className="input" placeholder="Search projects, tasks..." style={{ paddingLeft: 32, height: 36, marginLeft: -24, width: "calc(100% + 24px)" }} />
          </div>
          <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 8 }}>
            <button className="btn btn-ghost" onClick={() => setActivePage("notifications")} style={{ position: "relative", padding: 8 }}>
              <Icon name="notifications" size={18} />
              {NOTIFICATIONS_DATA.filter(n => !n.read).length > 0 && (
                <span style={{ position: "absolute", top: 4, right: 4, width: 8, height: 8, background: "var(--red)", borderRadius: "50%", border: "2px solid var(--bg2)" }} />
              )}
            </button>
            <button className="btn btn-ghost" onClick={() => setActivePage("settings")} style={{ padding: 8 }}>
              <Icon name="settings" size={18} />
            </button>
            <div style={{ width: 1, height: 24, background: "var(--border)" }} />
            <div style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer" }} onClick={() => setActivePage("settings")}>
              <Avatar user={user} size={30} />
              <div>
                <div style={{ fontSize: 13, fontWeight: 600, lineHeight: 1.2 }}>{user?.name}</div>
                <div style={{ fontSize: 11, color: "var(--text3)" }}>{user?.role === "MAIN_PROJECT_MANAGER" ? "Project Manager" : user?.role}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Page content */}
        <div key={activePage} className="fade-in">
          {renderPage()}
        </div>
      </div>

      {toast && <Toast key={toast.id} message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}
